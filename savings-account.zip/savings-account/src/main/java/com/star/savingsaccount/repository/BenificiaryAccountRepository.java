/**
 * 
 */
package com.star.savingsaccount.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.star.savingsaccount.entity.BenificiaryAccount;

/**
 * @author User1
 *
 */
@Repository
public interface BenificiaryAccountRepository extends JpaRepository<BenificiaryAccount, Long> {

	Optional<BenificiaryAccount> findByAccountNumber(String account);

}
