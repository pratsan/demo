/**
 * 
 */
package com.star.savingsaccount.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.star.savingsaccount.entity.User;

/**
 * @author User1
 *
 */
@Repository
public interface UserRepository extends JpaRepository<User, Long> {

	public User findByEmailAndPassword(String email, String password);

}
