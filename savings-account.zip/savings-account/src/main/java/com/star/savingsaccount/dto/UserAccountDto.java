package com.star.savingsaccount.dto;

public class UserAccountDto {

}
