/**
 * 
 */
package com.star.savingsaccount.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

/**
 * @author User1
 *
 */
@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

	@ExceptionHandler(FundTransferException.class)
	public ResponseEntity<ErrorResponse> error(FundTransferException ex) {
		ErrorResponse er = new ErrorResponse();

		// .setMessage(ex.getMessage());
		er.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
		return new ResponseEntity<>(er, HttpStatus.NOT_ACCEPTABLE);

	}

	@ExceptionHandler(TransactionException.class)
	public ResponseEntity<ErrorResponse> error(TransactionException ex) {
		ErrorResponse er = new ErrorResponse();

		er.setStatus(HttpStatus.BAD_REQUEST.value());
		return new ResponseEntity<>(er, HttpStatus.BAD_REQUEST);

	}

}
