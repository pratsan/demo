/**
 * 
 */
package com.star.savingsaccount.service;

import org.springframework.stereotype.Component;

import com.star.savingsaccount.dto.HistoryReqDto;
import com.star.savingsaccount.dto.HistoryRespDto;
import com.star.savingsaccount.exception.TransactionException;

/**
 * @author User1
 *
 */
@Component
public interface TransactionHistoryService {

	/**
	 * @param userId - to get the summary for particular userId
	 * @param historyReqDto - contains the fromdate and to date as a request params
	 * @return - returns the list of transaction history
	 * @throws TransactionException - throws custome exception and succes mg if all is good
	 */
	public HistoryRespDto transactionHistory(Long userId, HistoryReqDto historyReqDto) throws TransactionException;

}
