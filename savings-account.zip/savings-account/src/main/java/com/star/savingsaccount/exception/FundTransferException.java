package com.star.savingsaccount.exception;

public class FundTransferException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FundTransferException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
