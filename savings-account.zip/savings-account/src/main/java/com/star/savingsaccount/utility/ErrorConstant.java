package com.star.savingsaccount.utility;

public class ErrorConstant {
	

}
