/**
 * 
 */
package com.star.savingsaccount.service;

import java.util.Date;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.star.savingsaccount.dto.BenificiaryAccountDto;
import com.star.savingsaccount.dto.ResponseDto;
import com.star.savingsaccount.entity.BenificiaryAccount;
import com.star.savingsaccount.repository.BenificiaryAccountRepository;

/**
 * @author User1
 *
 */

@Service
public class BenificiaryAccountServiceImpl implements BenificiaryAccountService {
	
	
	@Autowired
	BenificiaryAccountRepository benificiaryAccountRepository;
	
	
	@Override
	public ResponseDto beneficiaryRegistration(BenificiaryAccountDto benificiaryAccountDto) {
	BenificiaryAccount benificiaryAccount = new BenificiaryAccount();
	ResponseDto responseDto = new ResponseDto();

	if (benificiaryAccountDto == null) {
	responseDto.setStatusMessage("benificiaryAccountDto is null or empty");
	responseDto.setStatusCode(HttpStatus.BAD_REQUEST.value());
	} else {

	benificiaryAccount.setBeneficiaryAddeddate(new Date());

	BeanUtils.copyProperties(benificiaryAccountDto, benificiaryAccount);

	if (benificiaryAccountRepository.save(benificiaryAccount) != null) {
	responseDto.setStatusCode(HttpStatus.OK.value());
	responseDto.setStatusMessage("Transfer is successfull");
	} else {
	responseDto.setStatusCode(HttpStatus.BAD_REQUEST.value());
	responseDto.setStatusMessage("some thing went wrong plz try again");
	}

	}

	return responseDto;

	}

	

}
