/**
 * 
 */
package com.star.savingsaccount.exception;

import java.util.List;

/**
 * @author Prateek
 *
 */

public class ErrorResponse {

	private String message;

	private int status;

	

	
	
	

	/**
	 * 
	 */
	public ErrorResponse() {

	}

	

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	

}
