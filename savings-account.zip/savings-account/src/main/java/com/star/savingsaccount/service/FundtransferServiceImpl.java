/**
 * 
 */
package com.star.savingsaccount.service;

import java.util.Date;
import java.util.Optional;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.star.savingsaccount.entity.BenificiaryAccount;
import com.star.savingsaccount.entity.TransactionHistory;
import com.star.savingsaccount.entity.User;
import com.star.savingsaccount.entity.UserAccount;
import com.star.savingsaccount.exception.TransactionException;
import com.star.savingsaccount.repository.BenificiaryAccountRepository;
import com.star.savingsaccount.repository.TransactionHistoryRepository;
import com.star.savingsaccount.repository.UserAccountRepository;
import com.star.savingsaccount.repository.UserRepository;

/**
 * @author User1
 *
 */
@Service
public class FundtransferServiceImpl implements FundtransferService {
	
	@Autowired
	private BenificiaryAccountRepository benificiaryAccountRepository;
	@Autowired
	private UserAccountRepository accountRepository;
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private TransactionHistoryRepository transactionHistoryRepository;
	@Autowired
	private EntityManager entityManager;
	
	
	@Override
	public void fundTransfer(TransactionHistory transactionHistory) throws TransactionException
	{
	String accountNumber=transactionHistory.getAccountNumber();

	Optional<BenificiaryAccount>  benificiaryAccount=benificiaryAccountRepository.findByAccountNumber(accountNumber);

	if(!benificiaryAccount.isPresent())
	{
	throw new TransactionException("not benificiary account found");
	}
	else
	{
	Optional<User> user=userRepository.findById(transactionHistory.getUserId());
	UserAccount senderAccount=user.get().getUserAccount();
	if(!user.isPresent())
	{
	throw new TransactionException("no user found");
	}
	Optional<UserAccount> recieverAccount=accountRepository.findByAccountNumber(accountNumber);
	if(senderAccount.getAvailableBalance()<transactionHistory.getAmount())
	{
	throw new TransactionException("less balance");
	}
	else
	{
	String accountnum=transactionHistory.getAccountNumber();//reciver
	transactionHistory.setTransactionDate(new Date());
	transactionHistory.setAccountNumber(senderAccount.getAccountNumber());
	transactionHistory.setRefNumber(generateRefrence(10));
	transactionHistoryRepository.save(transactionHistory);

	TransactionHistory recieverTransactionHistory=new TransactionHistory();
	recieverTransactionHistory.setAmount(transactionHistory.getAmount());
	recieverTransactionHistory.setNarration("credited");
	recieverTransactionHistory.setRefNumber(generateRefrence(10));
	recieverTransactionHistory.setTransactionDate(new Date());
	recieverTransactionHistory.setTransactionType("credit");
	recieverTransactionHistory.setAccountNumber(accountnum);
	recieverTransactionHistory.setUserId(recieverAccount.get().getUserAccountId());
	transactionHistoryRepository.save(recieverTransactionHistory);

	senderAccount.setAvailableBalance(senderAccount.getAvailableBalance()-transactionHistory.getAmount());
	recieverAccount.get().setAvailableBalance(recieverAccount.get().getAvailableBalance()+transactionHistory.getAmount());

	Session session=entityManager.unwrap(Session.class);


	Transaction transaction=session.beginTransaction();
	session.update(senderAccount);
	session.update(recieverAccount.get());
	transaction.commit();

	session.close();

	}



	}
	}

	static String generateRefrence(int n)
	{

	    // chose a Character random from this String
	    String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
	                                + "0123456789"
	                                + "abcdefghijklmnopqrstuvxyz";

	    // create StringBuffer size of AlphaNumericString
	    StringBuilder sb = new StringBuilder(n);

	    for (int i = 0; i < n; i++) {

	        // generate a random number between
	        // 0 to AlphaNumericString variable length
	        int index
	            = (int)(AlphaNumericString.length()
	                    * Math.random());

	        // add Character one by one in end of sb
	        sb.append(AlphaNumericString
	                      .charAt(index));
	    }

	    return sb.toString();
	}

	}


