/**
 * 
 */
package com.star.savingsaccount.service;

import com.star.savingsaccount.dto.BenificiaryAccountDto;
import com.star.savingsaccount.dto.ResponseDto;

/**
 * @author User1
 *
 */
public interface BenificiaryAccountService {
	
	public ResponseDto beneficiaryRegistration(BenificiaryAccountDto benificiaryAccountDto);
	

}
