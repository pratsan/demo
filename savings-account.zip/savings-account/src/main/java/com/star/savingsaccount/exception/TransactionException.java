/**
 * 
 */
package com.star.savingsaccount.exception;

/**
 * @author Jyoti
 * @since 
 *
 */
public class TransactionException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8418545146716522194L;

	public TransactionException(String message) {
		super(message);
	}
	
	
	

}
